package com.example.myquizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    EditText nameText;
    Button Start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText=(EditText) findViewById(R.id.PersonName);
        Start = (Button) findViewById(R.id.StartButton);
        Start.setOnClickListener((View.OnClickListener)MainActivity.this);



    }

    //private void onClickView(View view){
      //  Intent intent = new Intent(MainActivity.this,QuizQuestions.class);
       // intent.putExtra("Name", nameText.getText().toString());
       // startActivity(intent);
    //}


    @Override
    public void onClick(View v) {
        Intent intent;
        intent = new Intent(this,QuizQuestions.class);
        intent.putExtra("Name", nameText.getText().toString());
        startActivity(intent);

    }
}