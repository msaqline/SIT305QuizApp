package com.example.myquizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class LastPage extends AppCompatActivity {


    int maxQuestion;
    int score;
    String playername;
    TextView salutations;
    TextView scoreT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_page);

        scoreT = findViewById(R.id.ScoreView);
        salutations = findViewById(R.id.salutations);

        salutations.setText("Congratulations " + playername);
        scoreT.setText(score + "/" + maxQuestion);

        Intent intent = getIntent();
        score = intent.getIntExtra("score", 0);
        maxQuestion = intent.getIntExtra("maxQuestion",0);
        playername = intent.getStringExtra("Name");

    }

    public void OnClickRestart(View view)
    {
        finish();
    }

    public void OnClickFinish(View view){
        moveTaskToBack(true);
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }
}