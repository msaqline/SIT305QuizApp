package com.example.myquizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

public class QuizQuestions extends AppCompatActivity {

    ArrayList<String> Question = new ArrayList<String>();
    ArrayList<String[]> Answer = new ArrayList<String[]>();
    ArrayList<int[]> AnswerCheck =  new ArrayList<int[]>();

    ProgressBar progressBar;
    TextView question;
    Button answer1;
    Button answer2;
    Button answer3;
    Button answer4;

    int progressMax = 5;
    int currentques = 1;
    int button_selected;
    int completed = 0;
    int maximum_ques = 5;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_questions);

        Intent intent = getIntent();


        progressBar = findViewById(R.id.ProgressBar);
        question = findViewById(R.id.tv_Question);
        answer1 = findViewById(R.id.Option1);
        answer2 = findViewById(R.id.Option2);
        answer3 = findViewById(R.id.Option3);
        answer4 = findViewById(R.id.Option4);


        progressBar.setMax(progressMax);

        Question.add("A is correct");
        Answer.add(new String[]{"a","b","c","d"});
        AnswerCheck.add(new int[]{1,0,0,0});

        Question.add("B is correct");
        Answer.add(new String[]{"a","b","c","d"});
        AnswerCheck.add(new int[]{0,1,0,0});

        Question.add("C is correct");
        Answer.add(new String[]{"a","b","c","d"});
        AnswerCheck.add(new int[]{0,0,1,0});

        Question.add("D is correct");
        Answer.add(new String[]{"a","b","c","d"});
        AnswerCheck.add(new int[]{0,0,0,1});

        Question.add("A is correct");
        Answer.add(new String[]{"a","b","c","d"});
        AnswerCheck.add(new int[]{1,0,0,0});

        progressBar.setProgress(currentques -1);

        Display();



    }

    private void OnClickAns1(View view){
        answer1.setBackgroundColor(Color.parseColor("FFFF99"));
        button_selected = 1;

    }

    private void OnClickAns2(View view){
        answer1.setBackgroundColor(Color.parseColor("FFFF99"));
        button_selected = 2;

    }

    private void OnClickAns3(View view){
        answer1.setBackgroundColor(Color.parseColor("FFFF99"));
        button_selected = 3;

    }

    private void OnClickAns4(View view){
        answer1.setBackgroundColor(Color.parseColor("FFFF99"));
        button_selected = 4;

    }
    private void CheckAnswer(int choice, Button but){
        answer1.setBackgroundColor(Color.parseColor("#d3d3d3"));
        answer2.setBackgroundColor(Color.parseColor("#d3d3d3"));
        answer3.setBackgroundColor(Color.parseColor("#d3d3d3"));
        answer4.setBackgroundColor(Color.parseColor("#d3d3d3"));

        if(completed == currentques) return;

        completed += 1;
        int index = currentques -1;
        if(AnswerCheck.get(index)[choice]==1){
            but.setBackgroundColor(Color.parseColor("#90ee90"));
        }
        else{
            but.setBackgroundColor(Color.parseColor("#FF0000"));
            if(AnswerCheck.get(index)[0]==1)
                answer1.setBackgroundColor(Color.parseColor("#90ee90"));
            if(AnswerCheck.get(index)[0]==1)
                answer2.setBackgroundColor(Color.parseColor("#90ee90"));
            if(AnswerCheck.get(index)[0]==1)
                answer3.setBackgroundColor(Color.parseColor("#90ee90"));
            if(AnswerCheck.get(index)[0]==1)
                answer4.setBackgroundColor(Color.parseColor("#90ee90"));

        }
    }

    public void OnClickSubmit(View view){
        Button but = (Button)view;
        String buttonText = but.getText().toString();

        if(buttonText.equals("Submit")){
            if(button_selected == 0){
                CheckAnswer(0, answer1);
            }
            else if(button_selected == 1){
                CheckAnswer(0, answer2);
            }
            else if(button_selected == 2){
                CheckAnswer(0, answer2);
            }
            else if(button_selected == 3){
                CheckAnswer(0, answer2);
            }
            but.setText("next");
        }
        else{
            if(currentques + 1 > maximum_ques){
                Intent intent = new Intent(this, LastPage.class);
                startActivity(intent);
                finish();
            }
            else{
                currentques += 1;
                progressBar.setProgress(currentques - 1);
                but.setText("submit");

                Display();
            }
        }
    }
    private void Display(){
        answer1.setBackgroundColor(Color.parseColor("d3d3d3"));
        answer2.setBackgroundColor(Color.parseColor("d3d3d3"));
        answer3.setBackgroundColor(Color.parseColor("d3d3d3"));
        answer4.setBackgroundColor(Color.parseColor("d3d3d3"));

        int idx = currentques - 1;

        question.setText(Question.get(idx));
        answer1.setText(Answer.get(idx)[0]);
        answer2.setText(Answer.get(idx)[1]);
        answer3.setText(Answer.get(idx)[2]);
        answer4.setText(Answer.get(idx)[3]);
    }




}